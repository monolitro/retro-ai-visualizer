import { createIcons, icons } from 'lucide';
import { createVisualizer }   from './visualizer';
import './styles/retro.css';

// ——————————————
// 1) Inicializar iconos Lucide
// ——————————————
createIcons({ icons });

// ——————————————
// 2) Referencias al DOM (solo los elementos realmente usados)
// ——————————————
const loadBtn        = document.getElementById('loadBtn')       as HTMLButtonElement;
const queueBtn       = document.getElementById('queueBtn')      as HTMLButtonElement;
const prevBtn        = document.getElementById('prevBtn')       as HTMLButtonElement;
const playPauseBtn   = document.getElementById('playPauseBtn')  as HTMLButtonElement;
const nextBtn        = document.getElementById('nextBtn')       as HTMLButtonElement;
const systemAudioBtn = document.getElementById('systemAudioBtn')as HTMLButtonElement;
const fullscreenBtn  = document.getElementById('fullscreenBtn') as HTMLButtonElement;

const queueEl = document.getElementById('queue')  as HTMLUListElement;
const canvas  = document.getElementById('canvas') as HTMLCanvasElement;
const audioEl = document.getElementById('audio')  as HTMLAudioElement;

// ——————————————
// 3) Estado global
// ——————————————
let audioCtx:   AudioContext;
let analyser:   AnalyserNode;
let viz:        ReturnType<typeof createVisualizer>;
let queue:      string[] = [];
let current = 0;
let playing = false;

// ——————————————
// 4) Helpers
// ——————————————
function ensureAudioContext() {
  if (!audioCtx) {
    audioCtx = new (window.AudioContext || (window as any).webkitAudioContext)();
    analyser = audioCtx.createAnalyser();
    analyser.fftSize = 2048;
    viz = createVisualizer(audioCtx, analyser, canvas);
  }
}

async function loadTrack(index: number) {
  ensureAudioContext();
  const src = queue[index];
  if (!src) return;
  playing = false;
  updatePlayIcon();

  // pausamos cualquier fuente anterior
  audioEl.pause();
  audioEl.srcObject = null;
  audioEl.src = src;
  await audioEl.play();

  // conectamos el audio
  const srcNode = audioCtx.createMediaElementSource(audioEl);
  srcNode.connect(analyser);
  analyser.connect(audioCtx.destination);

  viz.start();
  playing = true;
  updatePlayIcon();
}

// ——————————————
// 5) Iconos Play/Pause
// ——————————————
const playIcon  = '<i data-lucide="play"></i>';
const pauseIcon = '<i data-lucide="pause"></i>';
function updatePlayIcon() {
  playPauseBtn.innerHTML = playing ? pauseIcon : playIcon;
  createIcons({ icons });
}

// ——————————————
// 6) Render cola
// ——————————————
function renderQueue() {
  queueEl.innerHTML = '';
  queue.forEach((_, i) => {
    const li = document.createElement('li');
    li.textContent = `Track ${i + 1}`;
    if (i === current) li.classList.add('active');
    li.addEventListener('click', async () => {
      current = i;
      await loadTrack(current);
      renderQueue();
    });
    queueEl.appendChild(li);
  });
}

// ——————————————
// 7) Eventos de UI
// ——————————————
// Cargar archivos locales
loadBtn.addEventListener('click', () => {
  const inp = document.createElement('input');
  inp.type = 'file';
  inp.accept = 'audio/*';
  inp.multiple = true;
  inp.onchange = async () => {
    const files = Array.from(inp.files || []);
    queue = files.map(f => URL.createObjectURL(f));
    current = 0;
    renderQueue();
    await loadTrack(current);
  };
  inp.click();
});

// Mostrar/ocultar cola
queueBtn.addEventListener('click', () => queueEl.classList.toggle('hidden'));

// Play/Pause
playPauseBtn.addEventListener('click', () => {
  if (!audioCtx) return;
  if (playing) {
    audioEl.pause();
    viz.stop();
    playing = false;
  } else {
    audioEl.play();
    viz.start();
    playing = true;
  }
  updatePlayIcon();
});

// Pista anterior/siguiente
prevBtn.addEventListener('click', async () => {
  if (current > 0) {
    current--;
    await loadTrack(current);
  }
});

nextBtn.addEventListener('click', async () => {
  if (current < queue.length - 1) {
    current++;
    await loadTrack(current);
  }
});

// Captura de audio del sistema (Experimental: getDisplayMedia)
systemAudioBtn.addEventListener('click', async () => {
  try {
    const stream = await (navigator.mediaDevices as any).getDisplayMedia({
      audio: { echoCancellation: false },
      video: false,
    });
    audioEl.srcObject = stream;
    ensureAudioContext();
    const source = audioCtx.createMediaStreamSource(stream);
    source.connect(analyser);
    analyser.connect(audioCtx.destination);

    systemAudioBtn.classList.add('active');
    viz.start();
    playing = true;
    updatePlayIcon();
  } catch (e) {
    console.error(e);
    alert('No se pudo capturar el audio. Asegúrate de permitir la captura de pantalla con audio.');
  }
});

// Salir de la captura del sistema cuando el stream termina
audioEl.addEventListener('pause', () => {
  systemAudioBtn.classList.remove('active');
});

// Pantalla completa
fullscreenBtn.addEventListener('click', () => {
  if (!document.fullscreenElement) {
    document.documentElement.requestFullscreen();
  } else {
    document.exitFullscreen();
  }
});
