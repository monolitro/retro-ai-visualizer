// src/global.d.ts
// Declaraciones de módulos externos sin typings oficiales
// Añade aquí las que vayas necesitando.

declare module 'butterchurn';
declare module 'butterchurn-presets';
